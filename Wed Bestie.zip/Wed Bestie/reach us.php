<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title>Reach Us</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="assets/images/favicon.png" alt="">
                </div>
            </div>
        </div>
        <!--container box-->

        <!-- end preloader -->
        <!-- Start header -->
         <!--header php link-->
      <?php if($header="reach us"); include 'header.php';?>
        <!-- end of header -->
        <!-- start wpo-page-title -->
        <section class="wpo-page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Reach Us</h2>
                            <ol class="wpo-breadcumb-wrap">
                                <li><a href="index.php">Home</a></li>
                                <li>Reach Us</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end page-title -->

        <!--Container-box-->
        <div class="wpo-box-style">

            <!-- start wpo-contact-pg-section -->
            <section class="wpo-contact-pg-section section-padding">
                <div class="container">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>Reach Us</span>
                            <h2>Contact Us
                            </h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                        <div class="col col-lg-10 offset-lg-1">
                            <div class="office-info">
                                <div class="row">
                                    <div class="col col-xl-4 col-lg-6 col-md-6 col-12">
                                        <div class="office-info-item">
                                            <div class="office-info-icon">
                                                <div class="icon">
                                                    <i class="fi flaticon-maps-and-flags"></i>
                                                </div>
                                            </div>
                                            <div class="office-info-text">
                                                <h2>Address</h2>
                                                <p>No 64, Ground Floor, Jermiah Road, Vepery, Purasawalkam,
                                                    Chennai -600007</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col col-xl-4 col-lg-6 col-md-6 col-12">
                                        <div class="office-info-item">
                                            <div class="office-info-icon">
                                                <div class="icon">
                                                    <i class="fi flaticon-email"></i>
                                                </div>
                                            </div>
                                            <div class="office-info-text">
                                                <h2>Email Us</h2>

                                                <p>wedbestie@gmail.com</p>
                                                <div class="reach-spa"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col col-xl-4 col-lg-6 col-md-6 col-12">
                                        <div class="office-info-item">
                                            <div class="office-info-icon">
                                                <div class="icon">
                                                    <i class="fi flaticon-phone-call"></i>
                                                </div>
                                            </div>
                                            <div class="office-info-text">
                                                <h2>Call Now</h2>
                                                <p>9566270468</p>
                                                <div class="reach-spa"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="wpo-contact-title">
                                <h2>Have Any Question?</h2>
                                <p>Use the contact form below and let us know about your next event to see how we can help!</p>
                            </div>
                            <div class="wpo-contact-form-area">
                                <form method="post" class="contact-validation-active" id="contact-form-main">
                                    <div>
                                        <input type="text" class="form-control" name="name" id="name"
                                            placeholder="Your Name*">
                                    </div>
                                    <div>
                                        <input type="email" class="form-control" name="email" id="email"
                                            placeholder="Your Email*">
                                    </div>
                                    <div>
                                        <input type="text" class="form-control" name="adress" id="adress"
                                            placeholder="Adress">
                                    </div>
                                    <div>
                                        <select name="service" class="form-control">
                                            <option disabled="disabled" selected="">Services</option>
                                            <option>Photography</option>
                                            <option>The Rehearsal Dinner</option>
                                            <option>The Afterparty</option>
                                            <option>Videographers</option>
                                            <option>Perfect Cake</option>
                                            <option>All Of The Above</option>
                                        </select>
                                    </div>
                                    <div class="fullwidth">
                                        <textarea class="form-control" name="note" id="note"
                                            placeholder="Message..."></textarea>
                                    </div>
                                    <div class="submit-area">
                                        <button type="submit" class="theme-btn-s4">Get in Touch</button>
                                        <div id="loader">
                                            <i class="ti-reload"></i>
                                        </div>
                                    </div>
                                    <div class="clearfix error-handling-messages">
                                        <div id="success">Thank you</div>
                                        <div id="error"> Error occurred while sending email. Please try again later.
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div> <!-- end container -->
            </section>
            <!-- end wpo-contact-pg-section -->

            <!--  start wpo-contact-map -->
            <section class="wpo-contact-map-section">
                <h2 class="hidden">Contact map</h2>
                <div class="wpo-contact-map">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d15545.026305397494!2d80.25020833615115!3d13.082918853312147!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sNo%2064%2C%20Ground%20Floor%2C%20Jermiah%20Road%2C%20Vepery%2C%20Purasawalkam%2C%20Chennai%20-600007!5e0!3m2!1sen!2sin!4v1680358166115!5m2!1sen!2sin"
                        width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </section>
            <!-- end wpo-contact-map -->

            <div class="ctas"></div>
            <!-- start wpo-cta-section -->

            <div class="wpo-cta-section-s2">
                <div class="conatiner-fluid">
                    <div class="wpo-cta-item">
                        <span><img src="assets/images/cta/1.png" alt=""></span>
                        <div class="cta-size">
                            <h3>We look forward to hearing from you!
                            </h3>
                            <br>
                        </div>


                        <a class="theme-btn-s2" href="reach us.php">Contact Us</a>
                    </div>
                </div>
            </div>

            <div class="ctas"></div>
            <!-- start of wpo-site-footer-section -->
           <!--footer php link-->
<?php include 'footer.php';?>
            <!-- end of wpo-site-footer-section -->

        </div>

    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>




</html>
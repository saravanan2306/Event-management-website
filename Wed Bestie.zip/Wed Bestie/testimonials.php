<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title>Testimonials</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="assets/images/favicon.png" alt="">
                </div>
            </div>
        </div>
        <!--container box-->

        <!-- end preloader -->
        <!-- Start header -->
         <!--header php link-->
         <?php if ($header="testimonials"); include 'header.php';?>
        <!-- end of header -->
        <!-- start wpo-page-title -->
        <section class="wpo-page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Testimonials</h2>
                            <ol class="wpo-breadcumb-wrap">
                                <li><a href="index.php">Home</a></li>
                                <li>Testimonials</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end page-title -->

        <!--Container-box-->
        <div class="wpo-box-style">

            <!--testimonials-->
            <div class="wpo-service-details-area section-padding">
                <div class="container">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>Testimonials</span>
                            <h2>WONDERFUL WORDS FROM OUR CLIENTS
                            </h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                        <div class="col-lg-12 col-12">
                            <div class="wpo-faq-section">
                              
                                <div class="row">
                                   
                                    <div class="col-lg-12 col-md-12 col-12">
                                        <div class="accordion" id="accordionExample">
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingOne">
                                                    <button class="accordion-button" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                                        aria-expanded="true" aria-controls="collapseOne">
                                                        Saranya Ravi- Chennai
                                                    </button>
                                                </h3>
                                                <div id="collapseOne" class="accordion-collapse collapse show"
                                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Wed Bestie is organizing everything you need. Super
                                                            réactive.They immediately understood our expectations. They
                                                            organized our wedding exactly as we wished even if he only
                                                            had one month to do it. Photography, decorations, Makeovers…
                                                            Everything was at a high level. Even better than we
                                                            expected. If you need to plan your wedding don’t hesitate….
                                                            Thanks for everything Wed Bestie. You made our dreams come
                                                            true.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingTwo">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                                        aria-expanded="false" aria-controls="collapseTwo">
                                                        Dheepa Natarajan- Chennai

                                                    </button>
                                                </h3>
                                                <div id="collapseTwo" class="accordion-collapse collapse"
                                                    aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Hired Wed Bestie Team for a Birthday Party and the way they
                                                            organized the decorations party was so professional and
                                                            beyond our expectations. They also come up with concepts for
                                                            the decorations which are new and in line with the latest
                                                            trends. They have solutions for decorations, makeup, and
                                                            Photography. Thanks for making the event a wonderful one.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingThree">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                        aria-expanded="false" aria-controls="collapseThree">
                                                        Mudussir ahamad - Vellore

                                                    </button>
                                                </h3>
                                                <div id="collapseThree" class="accordion-collapse collapse"
                                                    aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>"I am so happy that I chose Wed Bestie for my wedding! The
                                                            makeup artist is extremely talented and she created exactly
                                                            the look that I wanted. The decorations for my wedding and
                                                            reception were also beautiful. The photographers were very
                                                            professional, punctual, and patient on my big day. We all
                                                            loved Wed bestie and would recommend her to anyone!"
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingFour">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                        aria-expanded="false" aria-controls="collapseFour">
                                                        Ramya - Chennai

                                                    </button>
                                                </h3>
                                                <div id="collapseFour" class="accordion-collapse collapse"
                                                    aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Wed bestie was lovely to work with. Good at understanding the
                                                            brief, was flexible, and patient and we were very happy with
                                                            the finished photos. Particularly good at lighting too! The
                                                            makeup artist also gave me a look that was flawless and
                                                            timeless. The decoration ambiance for the evening reception
                                                            and morning muhurtha were quite different. The team handled
                                                            it very well.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingfive">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapsefive"
                                                        aria-expanded="false" aria-controls="collapsefive">
                                                        Krishnaraj - Pondicherry

                                                    </button>
                                                </h3>
                                                <div id="collapsefive" class="accordion-collapse collapse"
                                                    aria-labelledby="headingfive" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Wed Bestie has been our all-time lifesaver. May it be a
                                                            one-month away inaugural ceremony or a week-away
                                                            celebration, they always come to our aid and never leave
                                                            anything to the last minute. We have been continuously
                                                            availing of all of their decoration and photography
                                                            services. The best part is they take care of every minute
                                                            detail and make sure everything is done right. Look forward
                                                            to working with you and your team in all future upcoming
                                                            events.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-item">
                                                <h3 class="accordion-header" id="headingsix">
                                                    <button class="accordion-button collapsed" type="button"
                                                        data-bs-toggle="collapse" data-bs-target="#collapsesix"
                                                        aria-expanded="false" aria-controls="collapsesix">
                                                        Senthilnathan- Chennai

                                                    </button>
                                                </h3>
                                                <div id="collapsesix" class="accordion-collapse collapse"
                                                    aria-labelledby="headingsix" data-bs-parent="#accordionExample">
                                                    <div class="accordion-body">
                                                        <p>Fantastic, precise & quality execution of decoration by Wed
                                                            bestie and their team on the Reception & Wedding days of my
                                                            daughter. The photographer's coordination & commitment from
                                                            the beginning till the end. My daughter was highly
                                                            appreciative of her makeover at both the wedding and
                                                            reception.
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end wpo-faq-section -->
                        </div>

                    </div>
                </div>
            </div>


            <!-- start wpo-cta-section -->

            <div class="wpo-cta-section-s2">
                <div class="conatiner-fluid">
                    <div class="wpo-cta-item">
                        <span><img src="assets/images/cta/1.png" alt=""></span>
                        <div class="cta-size">
                            <h3>We look forward to hearing from you!
                            </h3>
                            <br>
                        </div>


                        <a class="theme-btn-s2" href="reach us.php">Contact Us</a>
                    </div>
                </div>
            </div>

            <div class="ctas"></div>
            <!-- start of wpo-site-footer-section -->
             <!--footer php link-->
<?php include 'footer.php';?>
            <!-- end of wpo-site-footer-section -->

        </div>

    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>




</html>
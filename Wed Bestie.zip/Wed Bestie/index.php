<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title>Wed Bestie</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="assets/images/favicon.png" alt="">
                </div>
            </div>
        </div>
        <!-- end preloader -->
    
        <!-- start-header-topbar -->
        <?php if($header="home"); include 'header.php';?>
        <!-- end-header-topbar -->

        <!-- start wpo-box-style -->

        <div class="wpo-box-style">
          
            <!-- start of hero -->
            <section class="wpo-hero-slider">
                <div class="swiper-container">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="slide-inner slide-bg-image" data-background="assets/images/slider/slide-1.jpg">
                                <!-- <div class="gradient-overlay"></div> -->
                                <div class="container-fluid">
                                    <div class="slide-content">
                                        <div data-swiper-parallax="300" class="slide-title">
                                            <h2>EVERY AUTHENTIC</h2>
                                            <h2>MOMENT CAPTURED</h2>
                                        </div>
                                        <div data-swiper-parallax="400" class="slide-text">
                                            <p>Effortless and Natural wedding photography that captures your unique
                                                story
                                            </p>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div data-swiper-parallax="500" class="slide-btns">
                                            <a href="about.php" class="theme-btn">Discover More</a>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end slide-inner -->
                        </div> <!-- end swiper-slide -->

                        <div class="swiper-slide">
                            <div class="slide-inner slide-bg-image" data-background="assets/images/slider/slide-2.jpg">
                                <!-- <div class="gradient-overlay"></div> -->
                                <div class="container-fluid">
                                    <div class="slide-content">
                                        <div data-swiper-parallax="300" class="slide-title">
                                            <h2>DECORS HELP YOU WITH</h2>
                                            <h2>YOUR VENUE DESIGN
                                            </h2>
                                        </div>
                                        <div data-swiper-parallax="400" class="slide-text">
                                            <p>The very best professionals to take your venue to the next level!
                                            </p>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div data-swiper-parallax="500" class="slide-btns">
                                            <a href="our services.php" class="theme-btn">Discover More</a>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end slide-inner -->
                        </div> <!-- end swiper-slide -->

                        <div class="swiper-slide">
                            <div class="slide-inner slide-bg-image" data-background="assets/images/slider/slide-3.jpg">
                                <!-- <div class="gradient-overlay"></div> -->
                                <div class="container-fluid">
                                    <div class="slide-content">
                                        <div data-swiper-parallax="300" class="slide-title">
                                            <h2>LOOKING GOOD IS ALL</h2>
                                            <h2>ABOUT FEELING GOOD</h2>

                                        </div>
                                        <div data-swiper-parallax="400" class="slide-text">

                                            <p>Our Makeup Artists can help you achieve any look elegant and graceful
                                            </p>
                                        </div>
                                        <div class="clearfix"></div>
                                        <div data-swiper-parallax="500" class="slide-btns">
                                            <a href="reach us.php" class="theme-btn">Discover More</a>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- end slide-inner -->
                        </div> <!-- end swiper-slide -->
                    </div>
                    <!-- end swiper-wrapper -->

                    <!-- swipper controls -->
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
            </section>
            <!-- end of wpo-hero-slide-section-->
            <!-- start of wpo-about-section -->
            <section class="wpo-about-section section-padding">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-12 col-12">
                            <div class="wpo-about-wrap">
                                <div class="wpo-about-item">
                                    <div class="wpo-about-img">
                                        <img src="assets/images/about/1.png" alt="">
                                    </div>
                                </div>
                                <div class="about-single-item">
                                    <div class="wpo-about-item-s2 wow rollIn" data-wow-duration="2s">
                                        <div class="wpo-about-img">
                                            <img src="assets/images/about/2.png" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="ab-shape">
                                    <img src="assets/images/about/shape.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-12 col-12">
                            <div class="wpo-about-text">
                                <div class="wpo-about-icon">
                                    <div class="icon">
                                        <img src="assets/images/about/thumb.png" alt="">
                                    </div>
                                </div>
                                <div class="wpo-about-icon-content">
                                    <h2>About Us</h2>
                                    <h3>“Turn Your dream wedding into reality”
                                    </h3>
                                    <p>Create the wedding that you’ve always dreamed about with Wed bestie. Offering
                                        years of experience in Indian Weddings, Reception, Sangeet, Corporate
                                        Industries, etc. We are a leading team of experts like photographers, Decors,
                                        and Makeup stylists, working on a one-to-one basis with each & every client to
                                        ensure that no detail is left out. We provide elegant, stylish, glamorous, and
                                        professional services in Chennai and around Tamilnadu.
                                        We Offer bespoke packages tailored to each couple's needs (no matter how big or
                                        small the wedding!),
                                    </p>
                                    <p> Wed bestie offers high-quality services at attractive
                                        prices.
                                        Wed bestie customizes the services as per your requirements and budgets.
                                        Our team combines a beautifully designed event that reflects their client's
                                        unique personality and style with a superbly executed plan creating
                                        unforgettable memories. We are a one-stop solution for wedding-related services.

                                    </p>
                                    <a class="theme-btn-s3" href="about.php">More About</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- end of wpo-about-section -->

            <!-- start wpo-service-section -->
            <section class="wpo-service-section-s2 section-padding">
                <div class="container">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>Our Services</span>
                            <h2>High-quality & reliable services, <br> all in one place
                            </h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="wpo-service-wrap">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-12">
                                <div class="wpo-service-item">
                                    <div class="wpo-service-text">
                                        <div class="s-icon">
                                            <i class="fi flaticon-gallery"></i>
                                        </div>
                                        <a href="our services.php">Photography</a>
                                        <p>We know how much your wedding photography will mean to you in the years to
                                            come.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12">
                                <div class="wpo-service-item">
                                    <div class="wpo-service-text">
                                        <div class="s-icon">
                                            <i class="fi flaticon-serving-dish"></i>
                                        </div>
                                        <a href="our services.php">Decoration</a>
                                        <p>We're passionate about wedding decorating and it is seen in the work that we
                                            do!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12">
                                <div class="wpo-service-item">
                                    <div class="wpo-service-text">
                                        <div class="s-icon">
                                            <i class="fi flaticon-edit"></i>
                                        </div>
                                        <a href="our services.php">Makeup Artist</a>
                                        <p>We are experienced and professional hair, makeup artists who provide luxury.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end container -->
            </section>

            <div class="counter-spa"></div>
            <!-- end wpo-service-section-->
            <!-- start wpo-fun-fact-section -->


            <section class="wpo-fun-fact-section">
                <div class="container">
                    <div class="row">
                        <div class="col col-xs-12">
                            <div class="wpo-fun-fact-grids clearfix">
                                <div class="grid">
                                    <div class="info">
                                        <h3><span class="odometer" data-count="100">00</span>%</h3>
                                        <p>Happy Clients</p>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="info">
                                        <h3><span class="odometer" data-count="200">00</span>+</h3>
                                        <p>Weddings</p>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="info">
                                        <h3><span class="odometer" data-count="120">00</span>+</h3>
                                        <p>Decorations</p>
                                    </div>
                                </div>
                                <div class="grid">
                                    <div class="info">
                                        <h3><span class="odometer" data-count="80">00</span>+</h3>
                                        <p>Makeovers
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="f-shape-1">
                        <img src="assets/images/f-shape-1.png" alt="">
                    </div>
                    <div class="f-shape-2">
                        <img src="assets/images/f-shape-2.png" alt="">
                    </div>
                </div>
            </section>
            <!-- end wpo-fun-fact-section -->

            <!-- start wpo-portfolio-section -->
            <section class="wpo-portfolio-section section-padding">
                <div class="container-fluid">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>Portfolio</span>
                            <h2>Browse our Full Gallery
                            </h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="sortable-gallery">
                        <div class="gallery-filters"></div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="portfolio-grids gallery-container clearfix">
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/1.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Maria & Robin</a></h4>
                                                <span>Austria- Feb 2013</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/2.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Rose & Harry</a></h4>
                                                <span>Austria- Jan 2023</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/3.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Aliana & David</a></h4>
                                                <span>Austria- Mar 2023</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/4.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Aliza & Ken</a></h4>
                                                <span>Austria- April 2023</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/5.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Michel & Dianee</a></h4>
                                                <span>Austria- May 2023</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/6.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Maria & Nevela</a></h4>
                                                <span>Austria- Jul 2023</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- end container -->
            </section>
            <!-- end wpo-portfolio-section -->

            <!-- start wpo-testimonials-section -->
            <section class="wpo-testimonials-section section-padding">
                <div class="container">



                    <div class="row align-items-center">



                        <div class="col-lg-4 col-12">

                            <div class="wpo-testimonials-img">
                                <img src="assets/images/testimonial/l-img.jpg" alt="">
                                <div class="wpo-testimonials-img-shape">
                                    <img src="assets/images/testimonial/shape.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 offset-lg-1 col-12">
                            <div class="wpo-testimonials-wrap">

                                <h2>Wonderful Words From Our Clients
                                </h2>
                                <div class="wpo-testimonials-active owl-carousel">
                                    <div class="wpo-testimonials-item">
                                        <p>Hired Wed Bestie Team for a Birthday Party and the way they organized the
                                            decorations party was so professional and beyond our expectations. They also
                                            come up with concepts for the decorations which are new and in line with the
                                            latest trends. They have solutions for decorations, makeup, and Photography.
                                            Thanks for making the event a wonderful one.

                                        </p>
                                        <div class="wpo-testimonial-info">
                                            <div class="wpo-testimonial-info-img">
                                                <img src="assets/images/testimonial/img-1.jpg" alt="">
                                            </div>
                                            <div class="wpo-testimonial-info-text">
                                                <h5>Dheepa Natarajan</h5>
                                                <span>Chennai
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpo-testimonials-item">
                                        <p>"I am so happy that I chose Wed Bestie for my wedding! The makeup artist is
                                            extremely talented and she created exactly the look that I wanted. The
                                            decorations for my wedding and reception were also beautiful. The
                                            photographers were very professional, punctual, and patient on my big day.
                                            We all loved Wed bestie and would recommend her to anyone!"

                                        </p>
                                        <div class="wpo-testimonial-info">
                                            <div class="wpo-testimonial-info-img">
                                                <img src="assets/images/testimonial/img-3.jpg" alt="">
                                            </div>
                                            <div class="wpo-testimonial-info-text">
                                                <h5>Mudussir ahamad</h5>
                                                <span> Vellore
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpo-testimonials-item">
                                        <p>Wed bestie was lovely to work with. Good at understanding the brief, was
                                            flexible, and patient and we were very happy with the finished photos.
                                            Particularly good at lighting too! The makeup artist also gave me a look
                                            that was flawless and timeless. The decoration ambiance for the evening
                                            reception and morning muhurtha were quite different. The team handled it
                                            very well.

                                        </p>
                                        <div class="wpo-testimonial-info">
                                            <div class="wpo-testimonial-info-img">
                                                <img src="assets/images/testimonial/img-2.jpg" alt="">
                                            </div>
                                            <div class="wpo-testimonial-info-text">
                                                <h5>Ramya</h5>
                                                <span>Chennai
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- end container -->

                <div class="wpo-testimonials-shape">
                    <img src="assets/images/testimonial/shape2.png" alt="">
                </div>
            </section>
            <!-- end wpo-testimonials-section -->





            <!-- end wpo-cta-section -->

            <!-- start wpo-blog-section -->
            <section class="wpo-blog-section-s2 section-padding">
                <div class="container">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>News</span>
                            <h2>From Our Blog</h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="wpo-blog-items">
                        <div class="row">
                            <div class="col col-lg-4 col-md-6 col-12">
                                <div class="wpo-blog-item">
                                    <div class="wpo-blog-img">
                                        <img src="assets/images/blog/img-1.jpg" alt="">
                                    </div>
                                    <div class="wpo-blog-content">
                                        <ul>
                                            <li>By <a href="blogs.php">Loura Sweety</a></li>
                                            <li>25 Sep 2021</li>
                                        </ul>
                                        <h2><a href="blogs.php">Best wedding gift you may
                                                like & choose.</a>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col col-lg-4 col-md-6 col-12">
                                <div class="wpo-blog-item">
                                    <div class="wpo-blog-img">
                                        <img src="assets/images/blog/img-2.jpg" alt="">
                                    </div>
                                    <div class="wpo-blog-content">
                                        <ul>
                                            <li>By <a href="blogs.php">David Luis</a></li>
                                            <li>23 Sep 2021</li>
                                        </ul>
                                        <h2><a href="blogs.php">Photography is the important part of wedding.</a>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col col-lg-4 col-md-6 col-12">
                                <div class="wpo-blog-item">
                                    <div class="wpo-blog-img">
                                        <img src="assets/images/blog/img-3.jpg" alt="">
                                    </div>
                                    <div class="wpo-blog-content">
                                        <ul>
                                            <li>By <a href="blogs.php">Aliana de</a></li>
                                            <li>21 Sep 2021</li>
                                        </ul>
                                        <h2><a href="blogs.php">Top 10 wedding fresh flower decoration idea.</a>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- end container -->
            </section>
            <!-- end wpo-blog-section -->

            <!-- start wpo-cta-section -->

            <div class="wpo-cta-section-s2">
                <div class="conatiner-fluid">
                    <div class="wpo-cta-item">
                        <span><img src="assets/images/cta/1.png" alt=""></span>
                        <div class="cta-size">
                            <h3>We look forward to hearing from you!
                            </h3>
                            <br>
                        </div>


                        <a class="theme-btn-s2" href="reach us.php">Contact Us</a>
                    </div>
                </div>
            </div>
            <div class="ctas"></div>

          <!--footer php link-->
<?php include 'footer.php';?>
        </div>

        <!-- end wpo-box-style -->




    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>

</html>
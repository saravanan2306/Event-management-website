  <!-- start of wpo-site-footer-section -->
  <footer class="wpo-site-footer">
                <div class="wpo-upper-footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="widget about-widget">
                                    <div class="logo widget-title">
                                        <a href="index.php">
                                            <img src="assets/images/logo.png" alt="blog">
                                        </a>
                                    </div>
                                    <p>Create the wedding that you’ve always dreamed about with Wed bestie. Offering
                                        years of experience in Indian Weddings.</p>
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <i class="ti-facebook"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="ti-twitter-alt"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="ti-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="ti-google"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col col-xl-3  col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="widget link-widget">
                                    <div class="widget-title">
                                        <h3>Quick links</h3>
                                    </div>
                                    <ul>
                                        <li><a href="about.php">About Us</a></li>
                                        <li><a href="our services.php">Our Services</a></li>
                                        <li><a href="portfolio.php">Portfolio</a></li>
                                        <li><a href="testimonials.php">Testimonials</a></li>
                                        <li><a href="blogs.php">Blogs</a></li>
                                        <li><a href="reach us.php">Reach Us</a></li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col col-xl-3  col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="widget wpo-service-link-widget">
                                    <div class="widget-title">
                                        <h3>Contact </h3>
                                    </div>
                                    <div class="contact-ft">

                                        <ul>
                                            <li><i class="fi flaticon-email"></i>wedbestie@gmail.com</li>
                                            <li><i class="fi flaticon-phone-call"></i>9566270468</li>
                                            <li><i class="fi flaticon-maps-and-flags"></i>No 64, Ground Floor, Jermiah
                                                Road, Vepery, Purasawalkam, <br> Chennai -600007
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="col col-xl-3  col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="widget instagram">
                                    <div class="widget-title">
                                        <h3>Portfolio</h3>
                                    </div>
                                    <ul class="d-flex">
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/1.jpg"
                                                    alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/2.jpg"
                                                    alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/3.jpg"
                                                    alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/4.jpg"
                                                    alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/5.jpg"
                                                    alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/6.jpg"
                                                    alt=""></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div> <!-- end container -->
                </div>
                <div class="wpo-lower-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col col-xs-12">
                                <p class="copyright"> &copy; 2023 Wed Bestie. Design By <a
                                        href="https://techades.com/">Techades</a>. All Rights Reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- end of wpo-site-footer-section -->
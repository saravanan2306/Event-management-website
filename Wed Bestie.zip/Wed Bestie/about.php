<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from wpocean.com/html/tf/loveme/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 13 Mar 2023 08:30:32 GMT -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title>About Us</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="assets/images/favicon.png" alt="">
                </div>
            </div>
        </div>
        <!--header php link-->
        <?php if($header="about"); include 'header.php';?>
        <!-- start wpo-page-title -->
        <section class="wpo-page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>About Us</h2>
                            <ol class="wpo-breadcumb-wrap">
                                <li><a href="index.php">Home</a></li>
                                <li>About Us</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end page-title -->

        <!--Container-box-->
        <div class="wpo-box-style">

            <!-- start of wpo-about-section -->
            <section class="wpo-about-section-s2 section-padding">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6 col-md-12 col-12">
                            <div class="wpo-about-wrap">
                                <div class="wpo-about-item">
                                    <div class="wpo-about-img">
                                        <img src="assets/images/about/1.png" alt="">
                                    </div>
                                </div>
                                <div class="ab-shape">
                                    <img src="assets/images/about/shape.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-12">
                            <div class="wpo-about-text">
                                <div class="wpo-about-icon">
                                    <div class="icon">
                                        <img src="assets/images/about/thumb.png" alt="">
                                    </div>
                                </div>
                                <div class="wpo-about-icon-content">
                                    <h2>About Us</h2>
                                    <h3>“Turn Your dream wedding into reality”
                                    </h3>
                                    <p>Create the wedding that you’ve always dreamed about with Wed bestie. Offering
                                        years of experience in Indian Weddings, Reception, Sangeet, Corporate
                                        Industries, etc. We are a leading team of experts like photographers, Decors,
                                        and Makeup stylists, working on a one-to-one basis with each & every client to
                                        ensure that no detail is left out. We provide elegant, stylish, glamorous, and
                                        professional services in Chennai and around Tamilnadu. We Offer bespoke packages
                                        tailored to each couple's needs (no matter how big or small the wedding!),
                                    </p>
                                    <p>
                                        Wed bestie offers high-quality services at attractive prices. Wed bestie
                                        customizes the services as per your requirements and budgets. Our team combines
                                        a beautifully designed event that reflects their client's unique personality and
                                        style with a superbly executed plan creating unforgettable memories. We are a
                                        one-stop solution for wedding-related services.</p>
                                    <ul>
                                        <li>Expert traditional,candid photography,videography,cinematography teams.
                                        </li>
                                        <li>Professionally designed decor at attractive prices
                                            .</li>
                                        <li>Talented make-up artists who ensure you look your best
                                            .</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- end of wpo-about-section -->

            <!-- start wpo-event-section -->
            <section class="wpo-event-section section-padding" id="event">
                <div class="container">
                    <div class="row">
                        <div class="wpo-section-title-s2">
                            <div class="section-title-simg">
                                <img src="assets/images/section-title2.png" alt="">
                            </div>
                            <h2>Why Us
                            </h2>
                            <div class="section-title-img">
                                <div class="round-ball"></div>
                            </div>
                        </div>
                    </div>
                    <div class="wpo-event-wrap">
                        <div class="row">
                            <div class="col col-lg-4 col-md-6 col-12">
                                <div class="wpo-event-item">
                                    <div class="wpo-event-text">
                                        <h2>Time
                                        </h2>

                                        <p> We can assist clients who are time short, due to demanding work
                                            schedules or busy family lives and also those who are trying to juggle
                                            both. With our knowledge and expertise, we can assist you with the
                                            complete planning process for decorations, photography, and makeovers
                                            just step in for certain areas as you require.

                                        </p>
                                    </div>
                                    <div class="event-shape-1">
                                        <img src="assets/images/event-shape-1.png" alt="">
                                    </div>
                                    <div class="event-shape-2">
                                        <img src="assets/images/event-shape-2.png" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="col col-lg-4 col-md-6 col-12">
                                <div class="wpo-event-item">
                                    <div class="wpo-event-text">
                                        <h2>Pleasure
                                        </h2>
                                        <p>We gain a great sense of pleasure from helping our clients to achieve their
                                            dream day and client satisfaction is important to us. We focus on
                                            listening intently to our clients, proposing options allow the client
                                            to remain in full control. We have a love of lists, spreadsheets, and
                                            schedules and a huge desire perfection.
                                        </p>
                                    </div>
                                    <div class="event-shape-1">
                                        <img src="assets/images/event-shape-1.png" alt="">
                                    </div>
                                    <div class="event-shape-2">
                                        <img src="assets/images/event-shape-2.png" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="col col-lg-4 col-md-6 col-12">
                                <div class="wpo-event-item">
                                    <div class="wpo-event-text">
                                        <h2>Flexibility
                                        </h2>
                                        <p>We offer a range of services available for you to select from according to
                                            your own needs and requirements. We also offer bespoke services tailored to
                                            your specific desires. Whichever level of service you choose you can rely on
                                            our friendly approach which delivers perfection a service at a consistently high
                                            standard.
                                        </p>
                                    </div>
                                    <div class="event-shape-1">
                                        <img src="assets/images/event-shape-1.png" alt="">
                                    </div>
                                    <div class="event-shape-2">
                                        <img src="assets/images/event-shape-2.png" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- end container -->
            </section>
            <!-- end wpo-event-section -->

            <!-- start wpo-portfolio-section -->
            <section class="wpo-portfolio-section section-padding">
                <div class="container-fluid">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>Portfolio</span>
                            <h2>Browse our Full Gallery
                            </h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="sortable-gallery">
                        <div class="gallery-filters"></div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="portfolio-grids gallery-container clearfix">
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/1.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Maria & Robin</a></h4>
                                                <span>Austria- Feb 2019</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/2.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Rose & Harry</a></h4>
                                                <span>Austria- Jan 2020</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/3.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Aliana & David</a></h4>
                                                <span>Austria- Mar 2020</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/4.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Aliza & Ken</a></h4>
                                                <span>Austria- April 2020</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/5.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Michel & Dianee</a></h4>
                                                <span>Austria- May 2020</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="grid">
                                        <div class="img-holder">
                                            <img src="assets/images/portfolio/6.jpg" alt="">
                                            <div class="hover-content">
                                                <h4><a href="portfolio.php">Maria & Nevela</a></h4>
                                                <span>Austria- Jul 2021</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- end container -->
            </section>
            <!-- end wpo-portfolio-section -->

            <!-- start wpo-testimonials-section -->
           
            <section class="wpo-testimonials-section section-padding">
                <div class="container">



                    <div class="row align-items-center">



                        <div class="col-lg-4 col-12">

                            <div class="wpo-testimonials-img">
                                <img src="assets/images/testimonial/l-img.jpg" alt="">
                                <div class="wpo-testimonials-img-shape">
                                    <img src="assets/images/testimonial/shape.png" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7 offset-lg-1 col-12">
                            <div class="wpo-testimonials-wrap">

                                <h2>Wonderful Words From Our Clients
                                </h2>
                                <div class="wpo-testimonials-active owl-carousel">
                                    <div class="wpo-testimonials-item">
                                        <p>Hired Wed Bestie Team for a Birthday Party and the way they organized the
                                            decorations party was so professional and beyond our expectations. They also
                                            come up with concepts for the decorations which are new and in line with the
                                            latest trends. They have solutions for decorations, makeup, and Photography.
                                            Thanks for making the event a wonderful one.

                                        </p>
                                        <div class="wpo-testimonial-info">
                                            <div class="wpo-testimonial-info-img">
                                                <img src="assets/images/testimonial/img-1.jpg" alt="">
                                            </div>
                                            <div class="wpo-testimonial-info-text">
                                                <h5>Dheepa Natarajan</h5>
                                                <span>Chennai
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpo-testimonials-item">
                                        <p>"I am so happy that I chose Wed Bestie for my wedding! The makeup artist is
                                            extremely talented and she created exactly the look that I wanted. The
                                            decorations for my wedding and reception were also beautiful. The
                                            photographers were very professional, punctual, and patient on my big day.
                                            We all loved Wed bestie and would recommend her to anyone!"

                                        </p>
                                        <div class="wpo-testimonial-info">
                                            <div class="wpo-testimonial-info-img">
                                                <img src="assets/images/testimonial/img-3.jpg" alt="">
                                            </div>
                                            <div class="wpo-testimonial-info-text">
                                                <h5>Mudussir ahamad</h5>
                                                <span> Vellore
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="wpo-testimonials-item">
                                        <p>Wed bestie was lovely to work with. Good at understanding the brief, was
                                            flexible, and patient and we were very happy with the finished photos.
                                            Particularly good at lighting too! The makeup artist also gave me a look
                                            that was flawless and timeless. The decoration ambiance for the evening
                                            reception and morning muhurtha were quite different. The team handled it
                                            very well.

                                        </p>
                                        <div class="wpo-testimonial-info">
                                            <div class="wpo-testimonial-info-img">
                                                <img src="assets/images/testimonial/img-2.jpg" alt="">
                                            </div>
                                            <div class="wpo-testimonial-info-text">
                                                <h5>Ramya</h5>
                                                <span>Chennai
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div> <!-- end container -->

                <div class="wpo-testimonials-shape">
                    <img src="assets/images/testimonial/shape2.png" alt="">
                </div>
            </section>
            <!-- end wpo-testimonials-section -->
            <div class="ctas"></div>
            <!-- start wpo-cta-section -->

            <div class="wpo-cta-section-s2">
                <div class="conatiner-fluid">
                    <div class="wpo-cta-item">
                        <span><img src="assets/images/cta/1.png" alt=""></span>
                        <div class="cta-size">
                            <h3>We look forward to hearing from you!
                            </h3>
                            <br>
                        </div>


                        <a class="theme-btn-s2" href="reach us.php">Contact Us</a>
                    </div>
                </div>
            </div>

            <div class="ctas"></div>
            <!--footer php link-->
<?php include 'footer.php';?>

        </div>

    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>


<!-- Mirrored from wpocean.com/html/tf/loveme/about.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 13 Mar 2023 08:30:32 GMT -->

</html>
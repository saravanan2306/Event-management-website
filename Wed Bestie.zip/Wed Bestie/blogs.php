<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title>Blogs</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="assets/images/favicon.png" alt="">
                </div>
            </div>
        </div>
        <!--container box-->

        <!-- end preloader -->
        <!-- Start header -->
         <!--header php link-->
         <?php if($header="blogs"); include 'header.php';?>
        <!-- end of header -->
        <!-- start wpo-page-title -->
        <section class="wpo-page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Blogs</h2>
                            <ol class="wpo-breadcumb-wrap">
                                <li><a href="index.php">Home</a></li>
                                <li>Blogs</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end page-title -->

        <!--Container-box-->
        <div class="wpo-box-style">

            <!--blog section-->
            <section class="wpo-blog-pg-section section-padding">
                <div class="container">
                    <div class="row">
                        <div class="wpo-section-title">
                            <span>News</span>
                            <h2>From Our Blog</h2>
                            <div class="section-title-img">
                                <img src="assets/images/section-title.png" alt="">
                            </div>
                        </div>
                        <div class="col col-lg-10 offset-lg-1">
                            <div class="wpo-blog-content">
                                <div class="post format-standard-image">
                                    <div class="entry-media">
                                        <img src="assets/images/blog/img-4.jpg" alt>
                                    </div>
                                    <div class="entry-meta">
                                        <ul>
                                            <li><i class="fi flaticon-user"></i> By <a href="blogs detail.php">Jenny Watson</a> </li>
                                            <li><i class="fi flaticon-comment-white-oval-bubble"></i> Comments 35 </li>
                                            <li><i class="fi flaticon-calendar-1"></i> 24 Jun 2021</li>
                                        </ul>
                                    </div>
                                    <div class="entry-details">
                                        <h3><a href="blogs detail.php">Best wedding gift you may like & choose.</a></h3>
                                        <p>Consulting is a great career path if you want to build a broad skill set that
                                            includes everything from critical thinking and strategic planning to
                                            communications. If you love rising to a challenge.</p>
                                        <a href="blogs detail.php" class="read-more">READ MORE...</a>
                                    </div>
                                </div>
                                

                                <div class="post format-standard-image">
                                    <div class="entry-media">
                                        <img src="assets/images/blog/img-4.jpg" alt>
                                    </div>
                                    <div class="entry-meta">
                                        <ul>
                                            <li><i class="fi flaticon-user"></i> By <a href="blogs detail.php">Jenny Watson</a> </li>
                                            <li><i class="fi flaticon-comment-white-oval-bubble"></i> Comments 35 </li>
                                            <li><i class="fi flaticon-calendar-1"></i> 24 Jun 2021</li>
                                        </ul>
                                    </div>
                                    <div class="entry-details">
                                        <h3><a href="blogs detail.php">Best wedding gift you may like & choose.</a></h3>
                                        <p>Consulting is a great career path if you want to build a broad skill set that
                                            includes everything from critical thinking and strategic planning to
                                            communications. If you love rising to a challenge.</p>
                                        <a href="blogs detail.php" class="read-more">READ MORE...</a>
                                    </div>
                                </div>
                                <div class="post format-video">
                                    <div class="entry-media video-holder">
                                        <img src="assets/images/blog/img-6.jpg" alt>
                                       

                                    </div>
                                    <div class="entry-meta">
                                        <ul>
                                            <li><i class="fi flaticon-user"></i> By <a href="blogs detail.php">Jenny Watson</a> </li>
                                            <li><i class="fi flaticon-comment-white-oval-bubble"></i> Comments 35 </li>
                                            <li><i class="fi flaticon-calendar-1"></i> 24 Jun 2021</li>
                                        </ul>
                                    </div>
                                    <div class="entry-details">
                                        <h3><a href="blogs detail.php">Photography is the important part of wedding.</a>
                                        </h3>
                                        <p>Consulting is a great career path if you want to build a broad skill set that
                                            includes everything from critical thinking and strategic planning to
                                            communications. If you love rising to a challenge.</p>
                                        <a href="blogs detail.php" class="read-more">READ MORE...</a>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div> <!-- end container -->
            </section>

            <!-- start wpo-cta-section -->

            <div class="wpo-cta-section-s2">
                <div class="conatiner-fluid">
                    <div class="wpo-cta-item">
                        <span><img src="assets/images/cta/1.png" alt=""></span>
                        <div class="cta-size">
                            <h3>We look forward to hearing from you!
                            </h3>
                            <br>
                        </div>


                        <a class="theme-btn-s2" href="reach us.php">Contact Us</a>
                    </div>
                </div>
            </div>

            <div class="ctas"></div>
            <!-- start of wpo-site-footer-section -->
          
              <!--footer php link-->
<?php include 'footer.php';?>
            <!-- end of wpo-site-footer-section -->

        </div>

    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>




</html>
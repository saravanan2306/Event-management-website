<!DOCTYPE html>
<html lang="en">




<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title>Our Services</title>
    <link href="assets/css/themify-icons.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/flaticon.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/animate.css" rel="stylesheet">
    <link href="assets/css/owl.carousel.css" rel="stylesheet">
    <link href="assets/css/owl.theme.css" rel="stylesheet">
    <link href="assets/css/slick.css" rel="stylesheet">
    <link href="assets/css/slick-theme.css" rel="stylesheet">
    <link href="assets/css/swiper.min.css" rel="stylesheet">
    <link href="assets/css/nice-select.css" rel="stylesheet">
    <link href="assets/css/owl.transitions.css" rel="stylesheet">
    <link href="assets/css/jquery.fancybox.css" rel="stylesheet">
    <link href="assets/css/odometer-theme-default.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper">
        <!-- start preloader -->
        <div class="preloader">
            <div class="vertical-centered-box">
                <div class="content">
                    <div class="loader-circle"></div>
                    <div class="loader-line-mask">
                        <div class="loader-line"></div>
                    </div>
                    <img src="assets/images/favicon.png" alt="">
                </div>
            </div>
        </div>
       
        <!-- end preloader -->
        <!-- Start header -->
         <!--header php link-->
         <?php if($header="services"); include 'header.php';?>
        <!-- end of header -->
        <!-- start wpo-page-title -->
        <section class="wpo-page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="wpo-breadcumb-wrap">
                            <h2>Our Services</h2>
                            <ol class="wpo-breadcumb-wrap">
                                <li><a href="index.php">Home</a></li>
                                <li>Makeup Artist</li>
                            </ol>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end page-title -->

        <!--Container-box-->
        <div class="wpo-box-style">



            <div class="wpo-service-details-area section-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-12">
                            <div class="wpo-minimal-wrap">
                                <div class="wpo-minimal-img">
                                    <img src="assets/images/service-single/1.jpg" alt="">
                                </div>

                            </div>

                            <div class="wpo-p-details-section">
                                <h5>Makeup Artist</h5>
                                <p>We are experienced and professional hair and makeup artists who provide luxury beauty
                                    services. We offer professional hair styling and makeup application for brides. We
                                    make High Style Bridal Makeup and Hairstyle to give every bride that stunning
                                    wedding day look. Our Artists are experts in both Hair & Makeup Design for all
                                    ethnicities. We provide professional help in draping sarees of different cultures
                                    and materials. Our Makeup & Hairstyling offers the best in Bridal Makeup, Party,
                                    Occasion, Reception, Engagement, Haldi, and Mehandi Makeup in Normal, HD, and
                                    Airbrush. Our services are available at venues in Chennai and all around Tamilnadu.
                                    Our Artists customize Makeup for each skin type. We provide high-quality skin care
                                    products for your makeup needs. We have years of experience and artistic techniques
                                    have developed into the ability to create countless different makeup & hair looks.
                                    We captured the beauty in every Bride and bring their vision to life. We are truly
                                    grateful for the opportunity to serve you on your special day.


                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-12">
                            <div class="blog-sidebar">

                                <div class="widget category-widget">
                                    <h3>Services</h3>
                                    <ul>
                                        <li><a href="services photography.php">Photography</a></li>
                                        <li><a href="services decorations.php"> Decorations</a></li>
                                        <li><a href="services makeup artist.php">Makeup Artist</a></li>


                                    </ul>
                                </div>

                                <div class="widget wpo-instagram-widget">
                                    <div class="widget-title">
                                        <h3>Portfolio</h3>
                                    </div>
                                    <ul class="d-flex">
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/1.jpg" alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/2.jpg" alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/3.jpg" alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/4.jpg" alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/5.jpg" alt=""></a></li>
                                        <li><a href="portfolio.php"><img src="assets/images/instragram/6.jpg" alt=""></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- start wpo-cta-section -->

            <div class="wpo-cta-section-s2">
                <div class="conatiner-fluid">
                    <div class="wpo-cta-item">
                        <span><img src="assets/images/cta/1.png" alt=""></span>
                        <div class="cta-size">
                            <h3>We look forward to hearing from you!
                            </h3>
                            <br>
                        </div>


                        <a class="theme-btn-s2" href="reach us.php">Contact Us</a>
                    </div>
                </div>
            </div>

            <div class="ctas"></div>
            <!-- start of wpo-site-footer-section -->
           <!--footer php link-->
<?php include 'footer.php';?>
            <!-- end of wpo-site-footer-section -->

        </div>

    </div>
    <!-- end of page-wrapper -->

    <!-- All JavaScript files
    ================================================== -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- Plugins for this template -->
    <script src="assets/js/modernizr.custom.js"></script>
    <script src="assets/js/jquery.dlmenu.js"></script>
    <script src="assets/js/jquery-plugin-collection.js"></script>
    <!-- Custom script for this template -->
    <script src="assets/js/script.js"></script>
</body>




</html>